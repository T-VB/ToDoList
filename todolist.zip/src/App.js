import { useState } from "react";
import "./App.css";

function App() {
  //1) for the "todo" box:
  //useState always returns an array with 2 items in it (base and set..)
  const [newTodo, setNewTodo] = useState("");

  //2) for the "todo" list:
  const [todos, setTodos] = useState([]);

  //4) in form below, we created a name for a new function that handle's the form submission,
  //here is that function:
  const handleNewTodoSubmit = (e) => {
    e.preventDefault();
    console.log(newTodo);
    // 6) using spread operator, we want to setTodos to include all todo's in the array plus the newTodo
    setTodos([...todos, newTodo]);
    //7) setNewTodo to empty string, this makes it so once button is clicked, the text box will go back to being empty.
    setNewTodo("");
  };

  //12) create function that handles the delete onclick, delIndex represnts the deleted item
  const handleDelete = (delIndex) => {
    const filteredTodos = todos.filter((todo, i) => {
      return i !== delIndex;
    });
    //13) setTodos to the a new arayy (filtered todo list with the deleted object gone)
    setTodos(filteredTodos);
  };
  return (
    <div className="App">
      <header className="App-header"></header>

      <form
        onSubmit={(e) => {
          // 3) create function that handles our event upon submission
          handleNewTodoSubmit(e);
        }}
      >
        {/* 5) onchange event that updates our newTodo each time the form is submitted */}
        {/* target refers the html element that triggered the event in input*/}
        {/* value stores the input from the input text area box */}
        <input
          onChange={(e) => {
            setNewTodo(e.target.value);
          }}
          type="text"
          // 8) adding value to onchange event so when newTodo state is change, it updates to that value
          value={newTodo}
        />
        <div>
          <button>Add</button>
        </div>
      </form>
      {/* 9) map/iterate through todo's and render to page, using 'todo' and 'i' for index*/}
      {todos.map((todo, i) => {
        return (
          // 10) add a key for each div below, represents a child element of each todo
          <div key={i}>
            <span>{todo}</span>
            {/* 11) add delete button with an onClick event,
            and name a new function that handles this button*/}
            <button
              onClick={(e) => {
                handleDelete(i);
              }}
            >
              Delete
            </button>
          </div>
        );
      })}
    </div>
  );
}

export default App;
